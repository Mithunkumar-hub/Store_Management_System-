<?php session_start(); ?>

<html>
       <head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<link href="main1.css" rel="stylesheet">
<link href="footer.css" rel="stylesheet">
</head>
    
    
<body>
    
<!------------------------------- navigation bar -------------------------->
<?php include "staff_nav_bar.html" ?>
<!------------------------------- navigation bar --------------------------> 


<div class="after_nav">
	
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6 company-content" style="">
			Since 1998, we’ve been leading the casual lifestyle revolution — helping people embrace everyday comfort. 
			Our soft, breathable and comfortable footwear invited young families to break the rules, kick back and enjoy
			 a comfortable, casual way of living. With over 7 million pairs of shoes sold every year in more than 16 
			 countries around the world, shoes world is a global brand,
			 a household name and a cultural icon that embodies the light-hearted spirit of its beloved basset hound.
			</div>
			<div class="col-sm">
				<img src="../image/shoe1.jpg" class="img-fluid" alt="shoe">
			</div>
		</div>
		
	
		<div class="row">
			<div class="col-sm">
				<img src="../image/shoe2.jpg" class="img-fluid" alt="shoe">
			</div>
			<div class="col-sm-6 company-content" style="">
			shoes world is the go-to footwear, accessory and apparel brand that delivers the right mix of timeless 
			style, dependable comfort and quality.We provide the world’s most comfortable and stylish shoes, accessories 
			and apparel to help consumers look and feel their best. We know we’ve done our job when we see people smile—the
			 purest expression of comfort and style.
			</div>
		</div>

<div class="row-fluid">
	<div class="col-sm">
<!-------------------------- footer ------------------------------------->
    <?php include "staff_footer.html"; ?>
<!-------------------------- footer ------------------------------------->
    
    </div>
</div>
</body>
</html>