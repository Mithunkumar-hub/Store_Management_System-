<?php session_start();?>
<html>
<head>
	<style>
		#showClock{
			width:100%;
			height:80px;
			background-color:orange;
			color:red;
			text-align:center;
			font-size:70px;
			letter-spacing:22px;
		}
	</style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
<link href="main.css" rel="stylesheet">
<link href="../footer.css" rel="stylesheet">
</head>
<body>
    
<!----------------------------- navigation bar start------------------------------>
<?php include "admin_nav_bar.html"; ?>
<!----------------------------- navigation bar end ------------------------------->
    
<div class="after_nav">
	
	<div class="container-fluid">
		<div class="row" style="">
			<div class="col">
			<heading>
					<h1 class="display-3" id="welcome-text" style="">
					<small class="text-muted">50% OFF Casual Shoes </small>
                    </h1>
					<h2 id="showClock"></h2>
					<p style="background-color:orange; width:100%; height:30px; text-align:center;">only today offfer,T&C apply etc.</p>
					<script>
						var clock= setInterval(clocktime,1000)
						function clocktime(){
						var d = new Date();
						var ram =d.toLocaleTimeString();
						document.getElementById('showClock').innerHTML=ram;
						}
					</script>
                   
                
            </heading>
			</div>
		</div>
		
		<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="../image/back3.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="../image/back2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="../image/back1.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
        <div class="row">
         <div class="col-sm">
				<img src="../image/shoe2.jpg" class="img-fluid" alt="autocluster">
			</div>
		
		
			<div class="col-sm-6 company-content" style="">
			Since 1998, we’ve been leading the casual lifestyle revolution — helping people embrace everyday comfort. 
			Our soft, breathable and comfortable footwear invited young families to break the rules, kick back and enjoy
			 a comfortable, casual way of living. With over 7 million pairs of shoes sold every year in more than 16 
			 countries around the world, shoes world is a global brand,
			 a household name and a cultural icon that embodies the light-hearted spirit of its beloved basset hound.
			</div>
			
		</div>
		
		
		
		<div class="row">
			<div class="col-sm">
				<img src="../image/shoe1.jpg" class="img-fluid" alt="autocluster">
			</div>
			<div class="col-sm-6 company-content" style="">
			shoes world is the go-to footwear, accessory and apparel brand that delivers the right mix of timeless 
			style, dependable comfort and quality.We provide the world’s most comfortable and stylish shoes, accessories 
			and apparel to help consumers look and feel their best. We know we’ve done our job when we see people smile—the
			 purest expression of comfort and style.
			</div>
		</div>
		<div class="row">
			<div class="col-sm company-content" style="">
		
			</div>
		</div>
		

<div class="row-fluid">
	<div class="col-sm">
    
<!-- footer start -->
<?php include"../footer.html" ?>
<!-- footer end -->
        
	</div>
		</div>
    
</body>
</html>