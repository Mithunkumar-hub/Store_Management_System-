
<?php session_start();?>
<html>
<head>
<title>Home page</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
<link href="main.css" rel="stylesheet">
<link href="../footer.css" rel="stylesheet">
</head>
<body>
    
<!----------------------------- navigation bar start------------------------------>
<?php include "Shopkeeper_nav_bar.html"; ?>
<!----------------------------- navigation bar end ------------------------------->
    
<div class="after_nav">
	
	<div class="container-fluid">
	
		<div class="row">
			<div class="col-sm-6 company-content" style="">
			Since 1998, we’ve been leading the casual lifestyle revolution — helping people embrace everyday comfort. 
			Our soft, breathable and comfortable footwear invited young families to break the rules, kick back and enjoy
			 a comfortable, casual way of living. With over 7 million pairs of shoes sold every year in more than 16 
			 countries around the world, shoes world is a global brand,
			 a household name and a cultural icon that embodies the light-hearted spirit of its beloved basset hound.
			</div>
			<div class="col-sm">
				<img src="../image/shoe1.jpg" class="img-fluid" alt="autocluster">
			</div>
		</div>
		
		<div class="row">
			<div class="col-sm">
				<img src="../image/shoe2.jpg" class="img-fluid" alt="autocluster">
			</div>
			<div class="col-sm-6 company-content" style="">
			shoes world is the go-to footwear, accessory and apparel brand that delivers the right mix of timeless 
			style, dependable comfort and quality.We provide the world’s most comfortable and stylish shoes, accessories 
			and apparel to help consumers look and feel their best. We know we’ve done our job when we see people smile—the
			 purest expression of comfort and style.
			</div>
		</div>

<div class="row-fluid">
	<div class="col-sm">
    
<!-- footer start -->
<?php include"../footer.html" ?>
<!-- footer end -->
	</div>
</div>
    
</body>
</html>